package com.fourcatsdev.aula04;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula04ApplicationTests {

	@Test
	void contextLoads() {
	}

}
