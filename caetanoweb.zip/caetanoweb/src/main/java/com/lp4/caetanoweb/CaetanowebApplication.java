package com.lp4.caetanoweb;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.lp4.caetanoweb.orm.Filme;
import com.lp4.caetanoweb.repositorio.FilmeRepositorio;



@SpringBootApplication
public class CaetanowebApplication {
	
	@Autowired
	FilmeRepositorio filmeRepository;
	 
	@RequestMapping("/")
	public String listarFilme(Model model) {
		model.addAttribute("filmes", filmeRepository.findAll());
		
		return "filmes";		
	}
	 
	@GetMapping("/adicionar")
	public String adicionarFilme(Model model) {
		model.addAttribute("filme", new Filme());
		return "formularioFilme";
	}
	
	@PostMapping("/salvar")
	public String salvarFilme(@Valid Filme filme, BindingResult result) {
		if (result.hasErrors()) {
			return "formularioFilme";
		}
		filmeRepository.save(filme);
		return "redirect:/";
	}


	public static void main(String[] args) {
		SpringApplication.run(CaetanowebApplication.class, args);
	}

}
