package com.lp4.caetanoweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CaetanowebApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(CaetanowebApplication.class, args);
	}

}
