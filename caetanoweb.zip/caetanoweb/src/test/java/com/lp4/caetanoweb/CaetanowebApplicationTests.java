package com.lp4.caetanoweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CaetanowebApplicationTests {

	@Test
	void contextLoads() {
	}

}
